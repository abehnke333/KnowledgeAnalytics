import os
import tensorflow as tf

# Turn off TensorFlow warning messages in program output
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# Define computational graph
X =
Y =

addition =


# Create the session
with tf.Session() as session:

    result =

    print(result)
